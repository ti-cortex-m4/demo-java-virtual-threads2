package eu.happycoders.demo.model;

public record Customer() {}

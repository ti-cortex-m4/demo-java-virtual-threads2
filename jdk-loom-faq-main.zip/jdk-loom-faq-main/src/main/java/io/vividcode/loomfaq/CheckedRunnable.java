package io.vividcode.loomfaq;

public interface CheckedRunnable {

  void run() throws Exception;
}
